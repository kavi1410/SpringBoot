package com.elan.RestController;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RestControllerApplicationTests {

	@Test
	void contextLoads() {
	}

}
